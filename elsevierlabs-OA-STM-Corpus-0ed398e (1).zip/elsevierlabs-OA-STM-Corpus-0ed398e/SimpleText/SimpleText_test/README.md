These 10 files have been corrected for sentence break errors and
other anomalous stuff like footnote content inserted in body text,
etc. - the one or two that are math content are probably the least
reliable, given the way formulas are inserted into sentences in
math papers, but the rest are in pretty good shape -

Sources of sentence break errors are mostly un-planned-for
abbreviations; there are abbrevs that are generally handled correctly,
like Fig., and a number of others that clearly were not envisaged
(Figs.)- here is a list of (most of) the sources of problems i found
while correcting these - capped versions of many of these also exist
-

fig.
figs.
eq.
eqs.
i.e.
e.g.
cf.
resp.

The other sentence-break issue has to do with footnote text: in
some journal content (but not all), the text of a footnote is
inserted at the point of the footnote symbol, which may be in the
middle of a sentence; when it is, the result is 2 sentence fragments
surrounding something that may or may not be a full sentence - my
solution was to delete all footnote text -

Ellen Hays
Elsevier Labs


