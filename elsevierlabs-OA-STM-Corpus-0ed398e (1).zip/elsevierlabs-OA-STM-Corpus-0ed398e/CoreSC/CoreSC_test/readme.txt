Annotations have been provided at a sentence level, with more than one annotation per sentence at times. Where this occurs, this is because the sentence covers more than one CoreSC category rather than being an either/or case. Annotations were performed using the Desktop version of SAPIENTA (http://www.sapientaproject.com/software#sapienta_soft) by correcting the results returned by the automated system.

As the paper describes primarily the implementation and feasibility of a biological protocol, the paper may have been different to more experiment driven papers that the SAPIENTA system was trained on.

This paper was manually annotated by a single annotator with excellent knowledge of the tool and annotation scheme but without biological domain expertise. Thus, its flawlessness should be taken with a pinch of salt…
